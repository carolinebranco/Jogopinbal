import javax.swing.JButton;
import javax.swing.JFrame;

public class SquareButtonExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Botão Quadrado");
        JButton button = new JButton("Clique Aqui");

        button.setBounds(50, 50, 100, 100); // Define a posição e o tamanho do botão

        frame.add(button);
        frame.setSize(300, 200); // Define o tamanho da janela
        frame.setLayout(null); // Desativa o layout automático
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}